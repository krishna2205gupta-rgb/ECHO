# ECHO Round 2 — Vercel Ready

## What was added
- Roll/position motion and breathing micro-interactions
- Hover/focus motion
- Bottom-sheet Echo reactions replacing a simple like
- “Why you see this” transparent relationship context
- Resonance / connection fading
- Let it fade → Memory concept
- Moment → Memory language
- Social Battery control
- Room matching explanation
- Room → Thread / Memory transition
- Functional Thread chat
- Browser persistence with localStorage

## Deploy
Push this folder to GitHub, import into Vercel, and deploy with Vite.
Build: `npm run build`
Output: `dist`
